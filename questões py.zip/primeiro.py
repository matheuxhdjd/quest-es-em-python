nome = input("Escreva seu nome\n")
print("Seja bem vindo")




