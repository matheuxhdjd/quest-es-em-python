print('Escreva um numero e direi se é par ou impar\n')
n1 = int(input('\n'))
if n1 % 2 == 0 :
    print('O numero é par\n')
else: 
    print('O numero é impar\n')