numero = int(input('Escreva um numero que te darei a raiz quadrada\n'))
raizQuadrada = numero ** 0.5
print(raizQuadrada)