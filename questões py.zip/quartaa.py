palavra = input("Escreva a palavra\n")
print(palavra[0])