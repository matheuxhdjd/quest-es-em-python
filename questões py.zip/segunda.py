print("Escreva dois numéros que te darei a soma: \n")
n1 = int(input("Escreva o primeiro numero\n"))
n2 = int(input('Escreva o segundo numero\n'))
soma = n1 + n2
print(soma)